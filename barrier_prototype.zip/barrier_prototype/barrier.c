#include "barrier.h"


/*
 * Initialize the barrier pointed to by b.
 * The pointer b already points to allocated memory,
 * so do not assign to it in this function.
 *
 */
void barrier_init(barrier_t* barrier, size_t num_threads) {
  barrier->num_threads     = num_threads;
  barrier->waiting_threads = 0;
  barrier->waking_threads  = 0;
  pthread_cond_init(&barrier->should_wait, NULL);
  pthread_cond_init(&barrier->should_wake, NULL);
  pthread_mutex_init(&barrier->lock, NULL);
}


/*
 * Wait at the barrier b until num_threads threads arrive
 */
void barrier_wait(barrier_t* barrier) {

  // lock
  pthread_mutex_lock(&barrier->lock);
  // a thread has arrived at the waiting stage
  barrier->waiting_threads = barrier->waiting_threads + 1;
  // each thread should sleep if not all have arrived
  if (barrier->waiting_threads == barrier->num_threads) {
    // wake all waiting threads if all threads have arrived at barrier
    barrier->waking_threads = 0;
    pthread_cond_broadcast(&barrier->should_wait);
  }
  while (barrier->waiting_threads < barrier->num_threads) {
    // thread should sleep
    pthread_cond_wait(&barrier->should_wait, &barrier->lock);
  }

  // a thread has arrived at the waking part of barrier
  barrier->waking_threads = barrier->waking_threads + 1;
  // reinitialize barrier threads but dont set threads_waiting to 0
  if (barrier->waking_threads == barrier->num_threads) {
    // let every thread leave the barrier and no more threads should be waiting
    barrier->waiting_threads = 0;
    pthread_cond_broadcast(&barrier->should_wake);
  }
  while (barrier->waking_threads < barrier->num_threads) {
    // thread should sleep
    pthread_cond_wait(&barrier->should_wake, &barrier->lock);
  }

  // unlock
  pthread_mutex_unlock(&barrier->lock);

}


/*
 * Clean up the barrier pointed to by b
 */
void barrier_destroy(barrier_t* barrier) {

  if (pthread_cond_destroy(&barrier->should_wait) != 0) {
    perror("The should_wait conditional variable was not destroyed properly\n");
  }
  if (pthread_cond_destroy(&barrier->should_wake) != 0) {
    perror("The should_wake conditional variable was not destroyed properly\n");
  }
  if (pthread_mutex_destroy(&barrier->lock) != 0) {
    perror("The lock was not destroyed properly\n");
  }

}
