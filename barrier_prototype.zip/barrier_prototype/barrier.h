#ifndef BARRIER_H
#define BARRIER_H

#include <pthread.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>



/* No thread can pass until all threads can pass */




// This makes the header file work for both C and C++
#ifdef __cplusplus
extern "C" {
#endif





typedef struct barrier {
  size_t num_threads;
  size_t waiting_threads;
  size_t waking_threads;
  // condition variable and lock for waiting
  pthread_mutex_t lock;
  pthread_cond_t should_wait;
  pthread_cond_t should_wake;
} barrier_t;

void barrier_init(barrier_t* b, size_t num_threads);

void barrier_wait(barrier_t* b);

void barrier_destroy(barrier_t* b);

// This makes the header file work for both C and C++
#ifdef __cplusplus
}
#endif

#endif
