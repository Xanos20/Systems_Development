#include <gtest/gtest.h>

#include "barrier.h"

#include <pthread.h>
#include <stdio.h>

barrier_t b;

void* thread_fn(void* arg) {
  printf("Thread in phase 1\n");
  barrier_wait(&b);
  printf("Thread in phase 2\n");
  barrier_wait(&b);
  printf("Thread in phase 3\n");
  return NULL;
}

void* thread4_fn(void* arg) {
  printf("Thread in phase 1\n");
  barrier_wait(&b);
  printf("Thread in phase 2\n");
  barrier_wait(&b);
  printf("Thread in phase 3\n");
  barrier_wait(&b);
  printf("Thread in phase 4\n");
  return NULL;
}

// more than two threads
// have them enter the barrier four to five times

TEST(BarrierTests, ExampleTest) {
  // This is an example test case. Write your own if you'd like to test your barrier before turning it in.

  // Initialize the barrier b to work with two threads
  barrier_init(&b, 2);

  // Create two threads
  pthread_t t1;
  pthread_t t2;
  ASSERT_EQ(0, pthread_create(&t1, NULL, thread_fn, NULL));
  ASSERT_EQ(0, pthread_create(&t2, NULL, thread_fn, NULL));

  // Join the threads
  ASSERT_EQ(0, pthread_join(t1, NULL));
  ASSERT_EQ(0, pthread_join(t2, NULL));
}

TEST(BarrierTests, ExampleTest2) {
  // Initialize the barrier b to work with two threads
  barrier_init(&b, 4);
  pthread_t t1;
  pthread_t t2;
  pthread_t t3;
  pthread_t t4;
  ASSERT_EQ(0, pthread_create(&t1, NULL, thread4_fn, NULL));
  ASSERT_EQ(0, pthread_create(&t2, NULL, thread4_fn, NULL));
  ASSERT_EQ(0, pthread_create(&t3, NULL, thread4_fn, NULL));
  ASSERT_EQ(0, pthread_create(&t4, NULL, thread4_fn, NULL));

  // Join the threads
  ASSERT_EQ(0, pthread_join(t1, NULL));
  ASSERT_EQ(0, pthread_join(t2, NULL));
  ASSERT_EQ(0, pthread_join(t3, NULL));
  ASSERT_EQ(0, pthread_join(t4, NULL));


}


TEST(BarrierTests, ExampleTest3) {
  // Initialize the barrier b to work with two threads
  barrier_init(&b, 4);
  pthread_t t1;
  pthread_t t2;
  pthread_t t3;
  pthread_t t4;
  ASSERT_EQ(0, pthread_create(&t1, NULL, thread4_fn, NULL));
  ASSERT_EQ(0, pthread_create(&t2, NULL, thread4_fn, NULL));
  ASSERT_EQ(0, pthread_create(&t3, NULL, thread4_fn, NULL));
  ASSERT_EQ(0, pthread_create(&t4, NULL, thread4_fn, NULL));

  // Join the threads
  ASSERT_EQ(0, pthread_join(t1, NULL));
  ASSERT_EQ(0, pthread_join(t2, NULL));
  ASSERT_EQ(0, pthread_join(t3, NULL));
  ASSERT_EQ(0, pthread_join(t4, NULL));


  ASSERT_EQ(0, pthread_create(&t1, NULL, thread_fn, NULL));
  ASSERT_EQ(0, pthread_create(&t2, NULL, thread_fn, NULL));
  ASSERT_EQ(0, pthread_create(&t3, NULL, thread_fn, NULL));
  ASSERT_EQ(0, pthread_create(&t4, NULL, thread_fn, NULL));

  // Join the threads
  ASSERT_EQ(0, pthread_join(t1, NULL));
  ASSERT_EQ(0, pthread_join(t2, NULL));
  ASSERT_EQ(0, pthread_join(t3, NULL));
  ASSERT_EQ(0, pthread_join(t4, NULL));


}

TEST(BarrierTests, ExampleTest4) {
  // Initialize the barrier b to work with two threads
  barrier_init(&b, 4);
  pthread_t t1;
  pthread_t t2;
  pthread_t t3;
  pthread_t t4;
  ASSERT_EQ(0, pthread_create(&t1, NULL, thread4_fn, NULL));
  ASSERT_EQ(0, pthread_create(&t2, NULL, thread4_fn, NULL));
  ASSERT_EQ(0, pthread_create(&t3, NULL, thread4_fn, NULL));
  ASSERT_EQ(0, pthread_create(&t4, NULL, thread4_fn, NULL));

  // Join the threads
  ASSERT_EQ(0, pthread_join(t1, NULL));
  ASSERT_EQ(0, pthread_join(t2, NULL));
  ASSERT_EQ(0, pthread_join(t3, NULL));
  ASSERT_EQ(0, pthread_join(t4, NULL));

  pthread_t t5;
  pthread_t t6;
  pthread_t t7;
  pthread_t t8;
  ASSERT_EQ(0, pthread_create(&t5, NULL, thread4_fn, NULL));
  ASSERT_EQ(0, pthread_create(&t6, NULL, thread4_fn, NULL));
  ASSERT_EQ(0, pthread_create(&t7, NULL, thread4_fn, NULL));
  ASSERT_EQ(0, pthread_create(&t8, NULL, thread4_fn, NULL));

  // Join the threads
  ASSERT_EQ(0, pthread_join(t5, NULL));
  ASSERT_EQ(0, pthread_join(t6, NULL));
  ASSERT_EQ(0, pthread_join(t7, NULL));
  ASSERT_EQ(0, pthread_join(t8, NULL));


}
