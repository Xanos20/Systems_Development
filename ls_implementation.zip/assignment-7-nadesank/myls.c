#include <dirent.h>
#include <grp.h>
#include <pwd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

void list_directory(const char* directory_name);

int main(int argc, char** argv) {
  // Process arguments
  if(argc == 1) {
    list_directory(".");
  } else if(argc == 2) {
    list_directory(argv[1]);
  } else {
    fprintf(stderr, "Please specify one or zero command line arguments.\n");
  }
  return 0;
}


/*
 * print_permissions
*/
void print_permissions(mode_t mode) {
  // is file a directory?
  if (S_ISDIR(mode) == 0) {
    printf("-");
  } else {
    printf("d");
  }
  /* USR Permissions */
  // read?
  if (S_IRUSR & mode) {
    printf("r");
  } else {
    printf("-");
  }
  // write?
  if (S_IWUSR & mode) {
    printf("w");
  } else {
    printf("-");
  }
  // execute?
  if (S_IXUSR & mode) {
    printf("x");
  } else {
    printf("-");
  }
  /* Group Permissions */
  if (S_IRGRP & mode) {
    printf("r");
  } else {
    printf("-");
  }
  if (S_IWGRP & mode) {
    printf("w");
  } else {
    printf("-");
  }
  if (S_IXGRP & mode) {
    printf("x");
  } else {
    printf("-");
  }
  /* OTHER Permissions */
  if (S_IROTH & mode) {
    printf("r");
  } else {
    printf("-");
  }
  if (S_IWOTH & mode) {
    printf("w");
  } else {
    printf("-");
  }
  if (S_IXOTH & mode) {
    printf("x");
  } else {
    printf("-");
  }

  return;

}


/*
 * List the permissions, user, group, file size, and file name of all the
 * contents in the current directory my_ls is run in
 *
 * Sources:
 * http://pubs.opengroup.org/onlinepubs/007904975/functions/getgrgid.html
 * http://pubs.opengroup.org/onlinepubs/009695399/functions/getpwuid.html
 */
void list_directory(const char* directory_name) {
  // TODO: Print the contents of the specified directory here
  DIR *dir;
  // Does this directory exist??
  if ((dir = opendir(directory_name)) == NULL) {
    fprintf(stderr, "Invalid argument for directory name.\n");
    exit(2);
  }
  // Look thorugh all files/directories in current directory
  struct dirent *d;
  struct stat data;
  while ((d = readdir(dir)) != NULL) {
    // retrives info from file/directory
    stat(d->d_name, &data);
    // permissions
    print_permissions(data.st_mode);
    // user id
    struct passwd *usr;
    if ((usr = getpwuid(data.st_uid)) != NULL) {
      printf(" %-8.8s", usr->pw_name);
    }
    if (usr == NULL) {
      fprintf(stderr, "Error in retriving user_id.\n");
      exit(2);
    }
    // group id
    struct group *grp;
    if ((grp = (getgrgid(data.st_gid))) != NULL) {
      printf(" %-8.8s", grp->gr_name);
    }
    if (grp == NULL) {
      fprintf(stderr, "Error in retriving group_id.\n");
      exit(2);
    }
    // print file/directory size
    printf("%lld ", data.st_size);
    // file/directory name
    printf("  %s\n", d->d_name);
  }
  // close directory
  closedir(dir);
  return;
}
