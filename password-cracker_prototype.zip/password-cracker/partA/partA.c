#define _GNU_SOURCE
#include <openssl/md5.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define PASSWORD_LENGTH 6

// USE MEMCOMPARE FOR MD5 HASHES

int md5_string_to_bytes(const char* md5_string, uint8_t* bytes);
void print_md5_bytes(const uint8_t* bytes);

int main(int argc, char** argv) {

  if(argc != 2) {
    fprintf(stderr, "Usage: %s <md5 sum of %d character password>\n", argv[0], PASSWORD_LENGTH);
    exit(1);
  }

  // This will hold the bytes of our md5 hash input
  uint8_t input_hash[MD5_DIGEST_LENGTH];

  // Convert the string representation of the MD5 hash to a byte array
  md5_string_to_bytes(argv[1], input_hash);

  // Now compute the MD5 hash of "passwd" (you should change this if you change PASSWORD_LENGTH)
  //char* plaintext = "passwd";
  //uint8_t password_hash[MD5_DIGEST_LENGTH];
  //MD5((unsigned char*)plaintext, strlen(plaintext), password_hash);

  // Print the hash that was passed in as a command line argument
  printf("You passed in the hash ");
  print_md5_bytes(input_hash);
  printf("\n");

  // Print the hash of "password"
  printf("The MD5 hash of \"%s\" is ", plaintext);
  print_md5_bytes(password_hash);
  printf("\n");

  // Check if the two hashes are equal
  if(memcmp(input_hash, password_hash, MD5_DIGEST_LENGTH) == 0) {
    printf("Those two hashes are equal!\n");
  } else {
    printf("Those hashes are not equal.\n");
  }

  return 0;
}

/**
 * Convert a string representation of an MD5 hash to a sequence
 * of bytes. The input md5_string must be 32 characters long, and
 * the output buffer bytes must have room for MD5_DIGEST_LENGTH
 * bytes.
 *
 * \param md5_string  The md5 string representation
 * \param bytes       The destination buffer for the converted md5 hash
 * \returns           0 on success, -1 otherwise
 */
int md5_string_to_bytes(const char* md5_string, uint8_t* bytes) {
  // Check for a valid MD5 string
  if(strlen(md5_string) != 2 * MD5_DIGEST_LENGTH) return -1;

  // Start our "cursor" at the start of the string
  const char* pos = md5_string;

  // Loop until we've read enough bytes
  for(size_t i=0; i<MD5_DIGEST_LENGTH; i++) {
    // Read one byte (two characters)
    int rc = sscanf(pos, "%2hhx", &bytes[i]);
    if(rc != 1) return -1;

    // Move the "cursor" to the next hexadecimal byte
    pos += 2;
  }

  return 0;
}

/**
 * Print a byte array that holds an MD5 hash to standard output.
 *
 * \param bytes   An array of bytes from an MD5 hash function
 */
void print_md5_bytes(const uint8_t* bytes) {
  for(size_t i=0; i<MD5_DIGEST_LENGTH; i++) {
    printf("%02hhx", bytes[i]);
  }
}


/**
 * Generate all passwords
 * original param = ['a','a','a','a','a','a','\0']
 * starting with the 5th position
 *
 **/
char* generatePassword(char* buffer, int position) {
      for(char c='a'; c <= 'z'; c++) {
        buffer[position] = c;
        if(position > 0){
          // move position down one space
          generatePassword(buffer, position--);
        } else {
          // Now compute the MD5 hash of "passwd" (you should change this if you change PASSWORD_LENGTH)
          uint8_t password_hash[MD5_DIGEST_LENGTH];
          MD5((unsigned char*)buffer, strlen(buffer), password_hash);

        }
      }

}
